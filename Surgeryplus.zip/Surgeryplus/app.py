from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.pdfgen import canvas

# Function to draw the background (header/footer/letterhead design)
def add_background(canv, doc):  # keep "doc" since reportlab requires it
    width, height = A4

    # Example header (hospital name)
    canv.setFont("Helvetica-Bold", 14)
    canv.drawString(40, height - 40, "Piptrackers Company Limited")

    # Example footer (address/contact)
    canv.setFont("Helvetica", 9)
    canv.drawString(40, 30, "15, Georgius Cole Estate, College Road,Ogba, Lagos")
    canv.drawString(40, 18, "Tel: +2347031989504 | https://www.eclinicplus.org")

# Create the PDF document
doc = SimpleDocTemplate("letterhead.pdf", pagesize=A4)
styles = getSampleStyleSheet()
story = []

# Add sample content
story.append(Spacer(1, 100))
story.append(Paragraph("Dear Sir/Madam,", styles["Normal"]))
story.append(Spacer(1, 12))
story.append(Paragraph(
    "This is a sample letter generated on the official hospital letterhead.",
    styles["Normal"]
))

# Build the PDF with background applied on each page
doc.build(story, onFirstPage=add_background, onLaterPages=add_background)
